
The first idea we attempted to work on was a superb chatbot (a bot on Telegram). We prepared the bot and created an account on a website to deploy it. However, we encountered a problem – the pretrained models we intended to use were large and required a GPU for execution. As a result, we decided to pivot towards creating a smaller chatbot specifically designed for kids. The goal was to assist them in understanding the distinction between good and bad words commonly encountered in their daily lives.

To optimize performance, we streamlined our approach by utilizing a single dataset instead of employing larger or diverse datasets. For instance, in the greetings section, we focused on using specific words.

It's important to note that we had to remove the dataset from the repository since GitHub has a file size limit of 25 MB.

Please ensure that you run this code in a Python environment that supports graphical interfaces, specifically Tkinter.